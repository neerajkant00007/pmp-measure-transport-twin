#!/usr/bin/env sh
# Reproduce every result of the paper (about 2-3 h on a 2-core CPU).
set -e
cd "$(dirname "$0")"
python scripts/01_generate_data.py                 # data/sim.pkl (2400 simulated builds, ~25 min)
for s in 0 1 2; do python scripts/02_forward_study.py $s; done   # Sections 6.2-6.3, Table 4
python scripts/03_sequential_study.py              # Section 6.4 (uses seed-0 models)
for s in 0 1 2; do python scripts/04_design_study.py $s; done    # Section 6.5
python scripts/05_aggregate.py                     # results/summary.json
python scripts/06_make_tables.py                   # results/table4.csv, results/paper_numbers.json
cd figures
python gen_illustration_data.py                    # data/illustration.pkl (Figs. 4-7)
python fig_schematics.py; python fig_testbed.py; python fig_cnf.py; python fig_fusion_seq.py
python make_r2.py; python fig_results2.py; python fig12.py   # figures/out/
