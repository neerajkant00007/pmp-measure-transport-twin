"""Collect every number reported in the paper from the result files: results/paper_numbers.json and
results/table4.csv (Table 4)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
from paths import RESULTS
import json, glob
import numpy as np

R = str(RESULTS)
S = json.load(open(f"{R}/summary.json"))
Q = json.load(open(f"{R}/sequential.json"))
DES = [json.load(open(f)) for f in sorted(glob.glob(f"{R}/design_seed*.json"))]
N = {}
ABBR = {"Proposed DT": "P", "No fusion": "NF", "No descriptors": "ND", "No hypernetwork": "NH", "GP surrogate": "GP", "MF-BNN": "BNN"}


def pm(v, d):
    return f"{v[0]:.{d}f} ± {v[1]:.{d}f}"


for n, a in ABBR.items():
    for t in (0, 10):
        s = S[f"test t={t} {n}"]
        N[f"{a}.t{t}.nll"] = pm(s["nll_per_dim"], 2)
        N[f"{a}.t{t}.nllm"] = f"{s['nll_per_dim'][0]:.2f}"
        for pn, k in (("yield strength", "sy"), ("elongation", "el"), ("log10 fatigue life", "lf")):
            if f"ECE {pn}" in s:
                N[f"{a}.t{t}.ece_{k}"] = pm(s[f"ECE {pn}"], 3)
                N[f"{a}.t{t}.ecem_{k}"] = f"{s[f'ECE {pn}'][0]:.3f}"
                N[f"{a}.t{t}.cov95_{k}"] = f"{s[f'coverage 0.95 {pn}'][0]:.3f}"
                N[f"{a}.t{t}.cov50_{k}"] = f"{s[f'coverage 0.5 {pn}'][0]:.2f}"
                N[f"{a}.t{t}.cov80_{k}"] = f"{s[f'coverage 0.8 {pn}'][0]:.2f}"
                N[f"{a}.t{t}.w95_{k}"] = pm(s[f"width 0.95 {pn}"], 2 if k == "lf" else (1 if k == "sy" else 2))
                N[f"{a}.t{t}.w95m_{k}"] = f"{s[f'width 0.95 {pn}'][0]:.{2 if k != 'sy' else 1}f}"
            N[f"{a}.t{t}.rmse_{k}"] = pm(s[f"rmse {pn}"], 3 if k == "lf" else (1 if k == "sy" else 2))
    N[f"{a}.W2"] = pm(S[f"ref W2 {n}"], 2)
    N[f"{a}.MMD"] = pm(S[f"ref MMD {n}"], 3)
    N[f"{a}.W2m"] = f"{S[f'ref W2 {n}'][0]:.2f}"
    N[f"{a}.modes"] = pm(S[f"ref mode_ratio {n}"], 2)
    for k in (1, 2, 3):
        N[f"{a}.R{k}.W2"] = f"{S[f'ref R{k} W2 {n}'][0]:.2f}"
    N[f"{a}.lat"] = f"{S[f'latency_ms {n}'][0]:.1f}"
    _tt = [json.load(open(fp))["train_time_s"][n] for fp in sorted(glob.glob(f"{R}/forward_seed*.json"))]
    N[f"{a}.train"] = f"{np.median(_tt) / 60:.1f}"
WORDS = {1: "one", 2: "two", 3: "three", 4: "four", 5: "five"}
N["nseeds"] = WORDS.get(S["n_seeds"], str(S["n_seeds"]))
_e = [S[f"test t=10 {n}"]["ECE yield strength"][0] for n in ("Proposed DT", "No fusion", "No hypernetwork", "GP surrogate", "MF-BNN")]
N["sy_ece_min"], N["sy_ece_max"] = f"{min(_e):.3f}", f"{max(_e):.3f}"
N["lambda_hi"] = pm(S["lambda"], 2)
N["lambda_hi_concat"] = pm(S["lambda_concat"], 2)

# sequential
ts = range(11)
for m in ("twin", "pf", "kf"):
    rows = Q["insitu"][m]
    for t in (0, 10):
        rr = [r for r in rows if r["t"] == t]
        N[f"seq.{m}.t{t}.cov_lf"] = f"{np.mean([r['cov_lf'] for r in rr]):.2f}"
        N[f"seq.{m}.t{t}.cov_sy"] = f"{np.mean([r['cov_sy'] for r in rr]):.2f}"
        N[f"seq.{m}.t{t}.w_lf"] = f"{np.mean([r['w_lf'] for r in rr]):.2f}"
        N[f"seq.{m}.t{t}.rmse_lf"] = f"{np.sqrt(np.mean([r['err_lf'] ** 2 for r in rr])):.3f}"
        N[f"seq.{m}.t{t}.rmse_sy"] = f"{np.sqrt(np.mean([r['err_sy'] ** 2 for r in rr])):.1f}"
pf10 = [r["ess"] for r in Q["insitu"]["pf"] if r["t"] == 10]
N["seq.pf.ess10_med"] = f"{100 * np.median(pf10):.1f}"
N["seq.pf.ess10_below5"] = f"{100 * np.mean(np.array(pf10) < 0.05):.0f}"
pf3 = [r["ess"] for r in Q["insitu"]["pf"] if r["t"] == 3]
N["seq.pf.ess3_med"] = f"{100 * np.median(pf3):.1f}"
N["seq.nbuilds"] = str(len([r for r in Q["insitu"]["twin"] if r["t"] == 0]))
w2 = np.array([(t, sw, v) for t, sw, v in Q["w2inc"] if t >= 2])
N["seq.w2_noswitch_med"] = f"{np.median(w2[w2[:, 1] == 0, 2]):.2f}"
N["seq.w2_switch_med"] = f"{np.median(w2[w2[:, 1] == 1, 2]):.2f}"
N["seq.n_switch"] = str(int((w2[:, 1] == 1).sum()))
N["seq.n_noswitch"] = str(int((w2[:, 1] == 0).sum()))
N["seq.eta"] = f"{Q['eta']:g}"
N["seq.n_ex"] = str(Q["n_exsitu"])
for m in ("prior", "twin", "pf", "kf"):
    e = Q["exsitu"][m]
    N[f"ex.{m}.cov_sy"] = f"{e['cov_sy']:.2f}"; N[f"ex.{m}.cov_lf"] = f"{e['cov_lf']:.2f}"
    N[f"ex.{m}.w_sy"] = f"{e['w_sy']:.1f}"; N[f"ex.{m}.w_lf"] = f"{e['w_lf']:.2f}"
    N[f"ex.{m}.rmse_sy"] = f"{e['err_sy']:.1f}"; N[f"ex.{m}.rmse_lf"] = f"{e['err_lf']:.3f}"

# design
if DES:
    N["des.nseeds"] = WORDS.get(len(DES), str(len(DES)))
    for m, a in (("Proposed DT", "P"), ("GP surrogate", "GP"), ("MF-BNN", "BNN")):
        its = [d[m][-1]["it"] if d[m][-1]["ok"] else None for d in DES]
        reached = [i for i in its if i is not None]
        N[f"des.{a}.reached"] = str(len(reached))
        N[f"des.{a}.its"] = ", ".join(str(i) if i is not None else ">10" for i in its)
        N[f"des.{a}.mean_its"] = f"{np.mean([i if i is not None else 11 for i in its]):.1f}"
        N[f"des.{a}.final_dev"] = pm([np.mean([d[m][-1]["dev"] for d in DES]), np.std([d[m][-1]["dev"] for d in DES], ddof=1) if len(DES) > 1 else 0], 2)
        N[f"des.{a}.best_dev"] = f"{np.mean([min(h['dev'] for h in d[m]) for d in DES]):.2f}"
json.dump(N, open(RESULTS / "paper_numbers.json", "w"), indent=1)

# Table 4 of the paper as CSV
rows = [("NLL, t=0 (nats/dim)", "t0.nll"), ("NLL, t=10 (nats/dim)", "t10.nll"), ("W2, R1-R3", "W2"), ("MMD, R1-R3", "MMD"),
        ("ECE, log10 Nf", "t10.ece_lf"), ("ECE, yield strength", "t10.ece_sy"), ("95% coverage, log10 Nf", "t10.cov95_lf"),
        ("95% width, log10 Nf", "t10.w95_lf"), ("RMSE, yield strength (MPa)", "t10.rmse_sy"), ("RMSE, elongation (%)", "t10.rmse_el"),
        ("RMSE, log10 Nf", "t10.rmse_lf"), ("Inference (ms, CPU)", "lat")]
cols = ["P", "NF", "ND", "NH", "GP", "BNN"]
with open(RESULTS / "table4.csv", "w") as fh:
    fh.write("Metric,Proposed DT,- fusion,- descriptors,- hypernetwork,GP surrogate,MF-BNN\n")
    for lab, key in rows:
        fh.write('"' + lab + '",' + ",".join('"' + N[f"{c}.{key}"] + '"' for c in cols) + "\n")
print(len(N), "numbers")
