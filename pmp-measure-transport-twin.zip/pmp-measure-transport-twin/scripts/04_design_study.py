"""Closed-loop process design (Section 6.5): each method proposes (P, v) maximising the predicted
probability of landing in a target property window (Eq. 18 with an indicator cost, solved on a
30 x 30 grid), the simulator 'builds' three replicates, and the model is updated.
Usage: python scripts/04_design_study.py SEED [SY_LO SY_HI EL_MIN]"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "figures"))
from paths import DATA, RESULTS, FIGOUT
import sys, json, time, copy
import numpy as np
import torch
import testbed as tb
import chain
import data as DM
import models as MD

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 0
if len(sys.argv) < 5:
    sys.argv = [sys.argv[0], str(SEED), "880", "920", "10"]   # target window of the paper
OUT = str(RESULTS)
SY_LO, SY_HI, EL_MIN = float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4])
N_INIT, MAX_IT, NREP = 60, 10, 3
import os
Q = os.environ.get('DES_QUICK') == '1'
if Q:
    MAX_IT = 1
SC = (lambda n: 10 if Q else n)
t0 = time.time()
S = DM.load()
A = DM.Assembler(S)
rng = np.random.default_rng(100 + SEED)
pool = S["train"]
init = [pool[i] for i in rng.permutation(len(pool))[:N_INIT]]
c_dim = 4 + A.kme.J
Pg, vg = np.meshgrid(np.linspace(*tb.P_RANGE, 30), np.linspace(*tb.V_RANGE, 30))
grid = np.c_[Pg.ravel(), vg.ravel()]


def cgrid():
    out = []
    for P, v in grid:
        b = {"P": P, "v": v}
        out.append(np.concatenate([chain.theta_n(b), [0.0, 0.0], np.zeros(A.kme.J)]))
    return np.array(out, dtype=np.float32)


CG = cgrid()


def in_window(x_std):
    sy = x_std[..., 4] * A.xs[4] + A.xm[4]
    el = x_std[..., 5] * A.xs[5] + A.xm[5]
    return (sy >= SY_LO) & (sy <= SY_HI) & (el >= EL_MIN)


def deviation(sy, el):
    d = max(SY_LO - sy, 0) / 50 + max(sy - SY_HI, 0) / 50 + max(EL_MIN - el, 0) / 2
    return d


def new_build(P, v, k):
    r = tb.simulate(P, v, seed=900000 + 1000 * SEED + k)
    b = {kk: r[kk] for kk in ("P", "v", "E", "pK", "modes", "f_eq", "porosity", "desc", "keyhole_frac", "mean_log_area", "max_pore", "n_pores", "mean_mis")}
    b["_obs"] = chain.observed_desc(b, np.random.default_rng(800000 + k), sd=A.sensor_sd)
    b["_x"] = {(u, f): chain.state(b, u, np.random.default_rng(700000 + 10 * k + 2 * u + (f == "lo")), f) for u in (0, 1) for f in ("hi", "lo")}
    return b


@torch.no_grad()
def p_window_flow(m, n=200):
    Ct = torch.as_tensor(CG)
    p = np.zeros(len(CG))
    for i in range(0, len(CG), 60):
        cx = MD.Flow.expand_ctx(m.context(Ct[i:i + 60]), n)
        x, _ = m.forward_map(torch.randn(cx[0].shape[0], MD.D), None, cx)
        p[i:i + 60] = in_window(x.view(-1, n, MD.D).numpy()).mean(1)
    return p


def p_window_gp(gp):
    from scipy.stats import norm
    mu, sd = gp.predict(CG[:, :3])
    sy_m, sy_s = mu[:, 4] * A.xs[4] + A.xm[4], sd[:, 4] * A.xs[4]
    el_m, el_s = mu[:, 5] * A.xs[5] + A.xm[5], sd[:, 5] * A.xs[5]
    return (norm.cdf(SY_HI, sy_m, sy_s) - norm.cdf(SY_LO, sy_m, sy_s)) * (1 - norm.cdf(EL_MIN, el_m, el_s))


@torch.no_grad()
def p_window_bnn(bnn, n=100):
    Ct = torch.as_tensor(CG)
    acc = np.zeros(len(CG))
    for _ in range(n):
        mu = bnn(Ct); x = mu + torch.exp(bnn.log_noise) * torch.randn_like(mu)
        acc += in_window(x.numpy())
    return acc / n


def run(method):
    data = list(init)
    tried = set()
    hist = []
    Xl, Cl = A.rows(pool, fidelity="lo")
    srcs = None
    for it in range(MAX_IT + 1):
        Xh, Ch = A.rows(data)
        if method == "Proposed DT":
            if it == 0:
                base = MD.Flow(c_dim, 8, kind="hyper", seed=SEED)
                base, _ = MD.train_flow(base, np.vstack([Xh, Xl]), np.vstack([Ch, Cl]), steps=SC(1000), seed=SEED)
                srcs = []
                for Xs, Cs in ((Xh, Ch), (Xl, Cl)):
                    s_ = MD.Flow(c_dim, 8, kind="hyper", seed=SEED); s_.load_state_dict(base.state_dict())
                    s_, _ = MD.train_flow(s_, Xs, Cs, steps=SC(400), lr=3e-4, seed=SEED)
                    for p in s_.parameters():
                        p.requires_grad_(False)
                    srcs.append(s_)
                lam = [0.8, 0.2]
                model = MD.Flow(c_dim, 8, kind="hyper", seed=SEED); model.load_state_dict(base.state_dict())
                model, _ = MD.train_flow(model, Xh, Ch, steps=SC(1500), lr=1e-3, sources=list(zip(lam, srcs)), beta=0.05, seed=SEED)
            else:
                model, _ = MD.train_flow(model, Xh, Ch, steps=SC(200), lr=3e-4, sources=list(zip(lam, srcs)), beta=0.05, seed=SEED + it)
            pw = p_window_flow(model)
        elif method == "GP surrogate":
            X0, C0 = A.rows(data, ts=(0,))                 # design queries are pre-build (t = 0): inputs P, v, u
            pw = p_window_gp(MD.GP(X0, C0[:, :3], seed=SEED))
        else:
            bnn = MD.train_bnn(Xh, Ch, steps=SC(1500), seed=SEED)
            pw = p_window_bnn(bnn)
        if it == MAX_IT:
            break
        order = np.argsort(-pw)
        k = next(i for i in order if i not in tried)
        tried.add(k)
        P, v = grid[k]
        mi = ("Proposed DT", "GP surrogate", "MF-BNN").index(method)
        reps = [new_build(P, v, 100 * mi + 10 * it + j) for j in range(NREP)]
        props = np.array([[b["_x"][(0, "hi")][4], b["_x"][(0, "hi")][5]] for b in reps])
        msy, mel = props.mean(0)
        ok = (SY_LO <= msy <= SY_HI) and (mel >= EL_MIN)          # replicate-mean properties inside the window
        dev = float(deviation(msy, mel))
        hist.append({"it": it + 1, "P": float(P), "v": float(v), "p_pred": float(pw[k]), "ok": bool(ok), "dev": dev,
                     "sy": float(msy), "el": float(mel)})
        print(method, hist[-1], round(time.time() - t0), flush=True)
        data += reps
        if ok:
            break
    return hist


res = {"seed": SEED, "window": [SY_LO, SY_HI, EL_MIN]}
for method in ("Proposed DT", "GP surrogate", "MF-BNN"):
    res[method] = run(method)
json.dump(res, open(f"{OUT}/design_seed{SEED}.json" if not Q else f"{OUT}/design_quick.json", "w"), indent=1)
print("done", round(time.time() - t0))
