import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "figures"))
from paths import DATA, RESULTS, FIGOUT
import sys, numpy as np, pickle, time
from multiprocessing import Pool
import testbed as t

KEYS = ("P", "v", "E", "pK", "modes", "f_eq", "porosity", "desc", "clusters", "keyhole_frac",
        "mean_log_area", "max_pore", "n_pores", "mean_mis")

def run(args):
    P, v, seed = args
    r = t.simulate(P, v, seed=seed)
    return {k: r[k] for k in KEYS}

def lhs(n, rng):
    u = (np.argsort(rng.random((2, n)), axis=1).T + rng.random((n, 2))) / n
    return t.P_RANGE[0] + u[:, 0] * (t.P_RANGE[1] - t.P_RANGE[0]), t.V_RANGE[0] + u[:, 1] * (t.V_RANGE[1] - t.V_RANGE[0])

if __name__ == "__main__":
    rng = np.random.default_rng(31)
    P, v = lhs(1500, rng)
    jobs = [(P[i], v[i], 200000 + i) for i in range(1500)]
    P2, v2 = lhs(300, rng)
    jobs += [(P2[i], v2[i], 300000 + i) for i in range(300)]
    refpts = [(180.0, 1300.0), (275.0, 760.0), (360.0, 560.0)]
    for j, (Pr, vr) in enumerate(refpts):
        jobs += [(Pr, vr, 400000 + 1000 * j + s) for s in range(200)]
    t0 = time.time()
    with Pool(2) as pool:
        res = pool.map(run, jobs, chunksize=8)
    pickle.dump(dict(train=res[:1500], test=res[1500:1800],
                     ref=[res[1800 + 200 * j:1800 + 200 * (j + 1)] for j in range(3)], refpts=refpts),
                open(DATA / "sim.pkl", "wb"))
    print("done", time.time() - t0, flush=True)
