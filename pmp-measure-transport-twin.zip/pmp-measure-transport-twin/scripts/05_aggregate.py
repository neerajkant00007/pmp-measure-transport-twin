"""Aggregate per-seed results into mean +/- SD summaries (results/summary.json)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "figures"))
from paths import DATA, RESULTS, FIGOUT
import json, glob
import numpy as np

R = [json.load(open(f)) for f in sorted(glob.glob(str(RESULTS / "forward_seed*.json")))]
NAMES = ["Proposed DT", "No fusion", "No descriptors", "No hypernetwork", "GP surrogate", "MF-BNN"]
out = {"n_seeds": len(R)}


def ms(vals):
    v = np.array(vals, float)
    return [float(v.mean()), float(v.std(ddof=1)) if len(v) > 1 else 0.0]


for t in (0, 10):
    for n in NAMES:
        keys = R[0][f"test t={t} {n}"].keys()
        out[f"test t={t} {n}"] = {k: ms([r[f"test t={t} {n}"][k] for r in R]) for k in keys}
for n in NAMES:
    for met in ("W2", "MMD", "mode_ratio"):
        per_seed = [np.mean([r[f"ref R{k} u={u} {n}"][met] for k in (1, 2, 3) for u in (0, 1)]) for r in R]
        out[f"ref {met} {n}"] = ms(per_seed)
        for k in (1, 2, 3):
            out[f"ref R{k} {met} {n}"] = ms([np.mean([r[f"ref R{k} u={u} {n}"][met] for u in (0, 1)]) for r in R])
    out[f"latency_ms {n}"] = ms([r[f"latency_ms {n}"] for r in R])
out["lambda"] = ms([r["lambda"][0] for r in R])
out["lambda_concat"] = ms([r["lambda_concat"][0] for r in R])
out["train_time_s"] = {n: ms([r["train_time_s"][n] for r in R]) for n in NAMES}
out["ref_modes_example"] = R[0]["ref R2 u=0 Proposed DT"]["ref_modes"]
json.dump(out, open(RESULTS / "summary.json", "w"), indent=1)

# compact print
for t in (0, 10):
    print(f"--- test builds, t={t}")
    for n in NAMES:
        s = out[f"test t={t} {n}"]
        print(f"{n:16s} NLL {s['nll_per_dim'][0]:6.3f}±{s['nll_per_dim'][1]:.3f} | ECE sy {s['ECE yield strength'][0]:.3f} lf {s['ECE log10 fatigue life'][0]:.3f}"
              f" | cov95 lf {s['coverage 0.95 log10 fatigue life'][0]:.3f} w95 lf {s['width 0.95 log10 fatigue life'][0]:.3f}"
              f" | RMSE sy {s['rmse yield strength'][0]:.1f} el {s['rmse elongation'][0]:.2f} lf {s['rmse log10 fatigue life'][0]:.3f}")
print("--- reference points (pre-build)")
for n in NAMES:
    print(f"{n:16s} W2 {out[f'ref W2 {n}'][0]:.3f}±{out[f'ref W2 {n}'][1]:.3f}  MMD {out[f'ref MMD {n}'][0]:.3f}  modes {out[f'ref mode_ratio {n}'][0]:.2f}  lat {out[f'latency_ms {n}'][0]:.1f} ms")
print("lambda(hi-fi)", out["lambda"])
