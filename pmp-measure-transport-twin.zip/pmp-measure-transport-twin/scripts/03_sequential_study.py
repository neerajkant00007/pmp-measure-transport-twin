"""Sequential assimilation study (Section 6.4): in-situ layer-by-layer updates and an ex-situ
virtual tensile test, proposed twin (amortised re-conditioning + JKO-type refinement, Eqs. 15-17)
vs. bootstrap particle filter and Kalman filter. Uses the seed-0 models of study_forward.py."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "figures"))
from paths import DATA, RESULTS, FIGOUT
import sys, json, time, copy, pickle
import numpy as np
import torch
import ot
from scipy.stats import norm
import data as DM
import models as MD

OUT = str(RESULTS)
t0 = time.time()
S = DM.load()
A = DM.Assembler(S)
rng = np.random.default_rng(0)
perm = rng.permutation(len(S["train"]))
hf = [S["train"][i] for i in perm[:300]]
val = [S["train"][i] for i in perm[300:400]]
c_dim = 4 + A.kme.J
st = torch.load(f"{OUT}/flows_seed0.pt")
twin = MD.Flow(c_dim, 8, kind="hyper"); twin.load_state_dict(st["Proposed DT"]); twin.eval()
gp = pickle.load(open(f"{OUT}/gp_seed0.pkl", "rb"))
for p in twin.parameters():
    p.requires_grad_(False)

SY, LF = 4, 6
test = S["test"][:int(__import__("os").environ.get("NTEST", "150"))]   # 150 test builds in the paper
NP = 300
TS = list(range(0, 11))

# learned linear-Gaussian observation model for the filters: layer descriptor ~ N(B x + b, diag s^2)
Xo, Yo = [], []
for b in hf:
    x = A.xstd(b, 0)
    for l in range(DM.NL):
        Xo.append(x); Yo.append((b["_obs"][l] - A.kme.mu) / A.kme.sd)
Xo, Yo = np.array(Xo), np.array(Yo)
Xa = np.hstack([Xo, np.ones((len(Xo), 1))])
Bm = np.linalg.lstsq(Xa, Yo, rcond=None)[0]
s2 = ((Yo - Xa @ Bm) ** 2).mean(0)
Bx, bb = Bm[:-1].T, Bm[-1]


@torch.no_grad()
def samples(c, n=NP, seed=0):
    g = torch.Generator().manual_seed(seed)
    ct = torch.as_tensor(c[None], dtype=torch.float32)
    ctx = MD.Flow.expand_ctx(twin.context(ct), n)
    z = torch.randn(n, MD.D, generator=g)
    x, _ = twin.forward_map(z, None, ctx)
    return x.numpy(), z


def cover(smp, truth, a=0.95):
    lo, hi = np.quantile(smp, [(1 - a) / 2, (1 + a) / 2])
    return float(lo <= truth <= hi), float(hi - lo)


rows = {"twin": [], "pf": [], "kf": []}
w2inc = []           # (t, switch?, W2 between successive twin posteriors)
for bi, b in enumerate(test):
    xt = A.xstd(b, 0)
    obs = (b["_obs"] - A.kme.mu) / A.kme.sd
    modes = b["modes"]
    prev = None
    # particle filter and Kalman filter initialisation (pre-build prior)
    parts, _ = samples(A.c_vec(b, 0, 0), seed=bi)
    logw = np.zeros(NP)
    mu0, sd0 = gp.predict(A.c_vec(b, 0, 0)[None])
    m, P = mu0[0].copy(), np.diag(sd0[0] ** 2)
    for t in TS:
        smp, _ = samples(A.c_vec(b, 0, t), seed=1000 + bi)
        if t > 0:
            y = obs[t - 1]
            logw += (-0.5 * ((y - (parts @ Bx.T + bb)) ** 2 / s2)).sum(1)
            Hm, R = Bx, np.diag(s2)
            Sx = Hm @ P @ Hm.T + R
            Kg = P @ Hm.T @ np.linalg.inv(Sx)
            m = m + Kg @ (y - (Hm @ m + bb)); P = (np.eye(MD.D) - Kg @ Hm) @ P
        w = np.exp(logw - logw.max()); w /= w.sum()
        ess = 1 / np.sum(w ** 2) / NP
        res_pf = parts[rng.choice(NP, NP, p=w)]
        for key, sm in (("twin", smp), ("pf", res_pf)):
            r = {"t": t, "build": bi}
            for j, nm in ((SY, "sy"), (LF, "lf")):
                c_, wd = cover(sm[:, j], xt[j]); r[f"cov_{nm}"] = c_; r[f"w_{nm}"] = wd * A.xs[j]
                r[f"err_{nm}"] = (sm[:, j].mean() - xt[j]) * A.xs[j]
            if key == "pf":
                r["ess"] = ess
            rows[key].append(r)
        r = {"t": t, "build": bi}
        for j, nm in ((SY, "sy"), (LF, "lf")):
            sdj = np.sqrt(P[j, j]); lo, hi = m[j] - 1.96 * sdj, m[j] + 1.96 * sdj
            r[f"cov_{nm}"] = float(lo <= xt[j] <= hi); r[f"w_{nm}"] = 2 * 1.96 * sdj * A.xs[j]; r[f"err_{nm}"] = (m[j] - xt[j]) * A.xs[j]
        rows["kf"].append(r)
        if prev is not None:
            sw = bool(modes[t - 1] != modes[t - 2]) if t >= 2 else False
            w2inc.append((t, sw, float(np.sqrt(ot.emd2(np.full(150, 1 / 150), np.full(150, 1 / 150), ot.dist(prev[:150], smp[:150]))))))
        prev = smp
    if bi % 50 == 0:
        print("in-situ", bi, round(time.time() - t0), flush=True)

# ------------------------------------------------------------------ ex-situ virtual tensile test (t = 10)
SIG_Y_OBS = 10.0 / A.xs[SY]           # 10 MPa measurement noise, standardised


def jko_refine(c, y, eta, steps=60, n=256, seed=0):
    """Eq. 15 with the synchronous-coupling bound E||T_w(z)-T_prev(z)||^2 >= W2^2 as proximity term and
    the KL term evaluated by Eq. 16; warm start from the current twin."""
    m = copy.deepcopy(twin)
    for p in m.parameters():
        p.requires_grad_(True)
    opt = torch.optim.Adam(m.parameters(), lr=1e-3)
    ct = torch.as_tensor(c[None], dtype=torch.float32)
    g = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        ctx_prev = twin.context(ct)
    for it in range(steps):
        z = torch.randn(n, MD.D, generator=g)
        with torch.no_grad():
            xp, _ = twin.forward_map(z, None, MD.Flow.expand_ctx(ctx_prev, n))
        ctx = MD.Flow.expand_ctx(m.context(ct), n)
        x, ld = m.forward_map(z, None, ctx)
        prox = ((x - xp) ** 2).sum(1).mean()
        neg_ent = (-0.5 * (z ** 2).sum(1) - ld).mean()           # E log rho (up to a constant)
        nll_obs = (0.5 * ((y - x[:, SY]) / SIG_Y_OBS) ** 2).mean()
        lp_prev = twin.log_prob(x, ct.expand(n, -1)).mean()     # target pi_t ∝ rho^(t-1) * likelihood
        loss = prox + eta * (neg_ent - lp_prev + nll_obs)
        opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        z = torch.randn(NP, MD.D, generator=g)
        x, _ = m.forward_map(z, None, MD.Flow.expand_ctx(m.context(ct), NP))
    return x.numpy()


def exsitu_eval(builds, eta, tag, nb=None):
    out = {"twin": [], "pf": [], "kf": []}
    for bi, b in enumerate(builds[:nb]):
        xt = A.xstd(b, 0)
        r_ = np.random.default_rng(5000 + bi)
        y = xt[SY] + SIG_Y_OBS * r_.standard_normal()
        c = A.c_vec(b, 0, 10)
        sm = jko_refine(c, y, eta, seed=bi)
        prior, _ = samples(c, seed=7000 + bi)
        w = np.exp(-0.5 * ((y - prior[:, SY]) / SIG_Y_OBS) ** 2); w /= w.sum()
        pf = prior[r_.choice(NP, NP, p=w)]
        mu, sd = gp.predict(c[None]); mu, var = mu[0], sd[0] ** 2       # GP prior; scalar Kalman update on yield strength
        k = var[SY] / (var[SY] + SIG_Y_OBS ** 2)
        # correlations are not available in the independent GP, so only the observed component is updated
        mu_post, var_post = mu.copy(), var.copy(); mu_post[SY] += k * (y - mu[SY]); var_post[SY] *= (1 - k)
        for key, smp in (("twin", sm), ("pf", pf), ("prior", prior)):
            r = {}
            for j, nm in ((SY, "sy"), (LF, "lf")):
                c_, wd = cover(smp[:, j], xt[j]); r[f"cov_{nm}"] = c_; r[f"w_{nm}"] = wd * A.xs[j]; r[f"err_{nm}"] = (smp[:, j].mean() - xt[j]) * A.xs[j]
            out.setdefault(key, []).append(r)
        r = {}
        for j, nm in ((SY, "sy"), (LF, "lf")):
            sdj = np.sqrt(var_post[j]); r[f"cov_{nm}"] = float(abs(mu_post[j] - xt[j]) <= 1.96 * sdj)
            r[f"w_{nm}"] = 2 * 1.96 * sdj * A.xs[j]; r[f"err_{nm}"] = (mu_post[j] - xt[j]) * A.xs[j]
        out["kf"].append(r)
    return out


def summ(lst):
    keys = lst[0].keys()
    return {k: float(np.mean([r[k] for r in lst])) if k.startswith(("cov", "w_")) else float(np.sqrt(np.mean([r[k] ** 2 for r in lst]))) for k in keys}


etas = {}
for eta in (0.2, 1.0, 5.0):
    o = exsitu_eval(val, eta, "val", nb=int(__import__("os").environ.get("NVAL", "20")))
    s = summ(o["twin"])
    etas[eta] = abs(s["cov_sy"] - 0.95) + abs(s["cov_lf"] - 0.95) + 0.1 * s["err_sy"] / 30
    print("eta", eta, s, flush=True)
eta_best = min(etas, key=etas.get)
ex = exsitu_eval(test, eta_best, "test", nb=min(150, len(test)))
res = {"eta_grid": {str(k): v for k, v in etas.items()}, "eta": eta_best,
       "insitu": rows, "w2inc": w2inc,
       "exsitu": {k: summ(v) for k, v in ex.items()}, "n_exsitu": min(150, len(test))}
json.dump(res, open(f"{OUT}/sequential.json", "w"))
print("done", round(time.time() - t0), flush=True)
