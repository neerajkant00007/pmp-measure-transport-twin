"""Forward-prediction study (Sections 6.2-6.3): proposed model, ablations and baselines, one seed per call.
Usage: python scripts/02_forward_study.py SEED"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "figures"))
from paths import DATA, RESULTS, FIGOUT
import sys, json, time, os
import numpy as np
import torch
import ot
from scipy.stats import gaussian_kde, norm
from scipy.signal import find_peaks
import data as DM
import models as MD

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 0
OUT = str(RESULTS)
os.makedirs(OUT, exist_ok=True)
N_HF, N_VAL = 300, 100
STEPS_PRE, STEPS_SRC, STEPS = 1500, 500, 2500
BETAS = (0.05,)
PROPS = {"yield strength": 4, "elongation": 5, "log10 fatigue life": 6}
LEVELS = (0.5, 0.8, 0.95)

t0 = time.time()
S = DM.load()
A = DM.Assembler(S)
rng = np.random.default_rng(SEED)
perm = rng.permutation(len(S["train"]))
hf = [S["train"][i] for i in perm[:N_HF]]
val = [S["train"][i] for i in perm[N_HF:N_HF + N_VAL]]
lof = S["train"]                                   # low-fidelity source covers the full design
Xh, Ch = A.rows(hf)
Xv, Cv = A.rows(val)
Xl, Cl = A.rows(lof, fidelity="lo")
Xh0, Ch0 = A.rows(hf, ts=(0,))                     # descriptor-free rows (ablation)
Xv0, Cv0 = A.rows(val, ts=(0,))
c_dim = Ch.shape[1]


def fusion_fit(kind, Xtr, Ctr, Xva, Cva):
    """Pretrain on pooled sources, fine-tune one map per source (aligned through the shared
    initialisation), weight sources by held-out predictive likelihood, then train the twin with Eq. 13."""
    base = MD.Flow(c_dim, 8, kind=kind, seed=SEED)
    base, _ = MD.train_flow(base, np.vstack([Xtr, Xl]), np.vstack([Ctr, Cl]), steps=STEPS_PRE, seed=SEED)
    srcs, lls = [], []
    for Xs, Cs in ((Xtr, Ctr), (Xl, Cl)):
        m = MD.Flow(c_dim, 8, kind=kind, seed=SEED); m.load_state_dict(base.state_dict())
        m, _ = MD.train_flow(m, Xs, Cs, steps=STEPS_SRC, lr=3e-4, seed=SEED)
        with torch.no_grad():
            lls.append(m.log_prob(torch.as_tensor(Xva), torch.as_tensor(Cva)).mean().item())
        for p in m.parameters():
            p.requires_grad_(False)
        srcs.append(m)
    w = np.exp(np.array(lls) - max(lls)); lam = w / w.sum()
    best = None
    for beta in BETAS:                                   # penalty weight selected on the validation split
        twin = MD.Flow(c_dim, 8, kind=kind, seed=SEED); twin.load_state_dict(base.state_dict())
        twin, vbest = MD.train_flow(twin, Xtr, Ctr, steps=STEPS, lr=1e-3, sources=list(zip(lam, srcs)), beta=beta,
                                    Xv=Xva, Cv=Cva, seed=SEED)
        if best is None or vbest < best[1]:
            best = (twin, vbest, beta)
    return best[0], lam.tolist(), base, srcs, best[2]


models = {}
timing = {}
tt = time.time(); models["Proposed DT"], lam, base, srcs, beta_sel = fusion_fit("hyper", Xh, Ch, Xv, Cv); timing["Proposed DT"] = time.time() - tt
tt = time.time()
m = MD.Flow(c_dim, 8, kind="hyper", seed=SEED)
models["No fusion"], _ = MD.train_flow(m, Xh, Ch, steps=STEPS, Xv=Xv, Cv=Cv, seed=SEED); timing["No fusion"] = time.time() - tt
tt = time.time()
m = MD.Flow(c_dim, 8, kind="hyper", seed=SEED); m.load_state_dict(base.state_dict())
models["No descriptors"], _ = MD.train_flow(m, Xh0, Ch0, steps=STEPS, lr=1e-3, sources=list(zip(lam, srcs)), beta=beta_sel,
                                             Xv=Xv0, Cv=Cv0, seed=SEED)
lam0 = lam; timing["No descriptors"] = time.time() - tt
tt = time.time(); models["No hypernetwork"], lamc, _, _, beta_c = fusion_fit("concat", Xh, Ch, Xv, Cv); timing["No hypernetwork"] = time.time() - tt
tt = time.time(); gp = MD.GP(Xh, Ch, seed=SEED); timing["GP surrogate"] = time.time() - tt
tt = time.time(); bnn = MD.train_bnn(Xh, Ch, seed=SEED); timing["MF-BNN"] = time.time() - tt
print("trained", round(time.time() - t0), flush=True)
if SEED == 0:
    torch.save({k: v.state_dict() for k, v in models.items()}, f"{OUT}/flows_seed0.pt")
    torch.save(bnn.state_dict(), f"{OUT}/bnn_seed0.pt")
    import pickle; pickle.dump(gp, open(f"{OUT}/gp_seed0.pkl", "wb"))


# ------------------------------------------------------------------ evaluation helpers
@torch.no_grad()
def flow_samples(m, C, n):
    Ct = torch.as_tensor(C, dtype=torch.float32)
    out = []
    for i in range(0, len(Ct), 50):
        ctx = MD.Flow.expand_ctx(m.context(Ct[i:i + 50]), n)
        z = torch.randn(ctx[0].shape[0], MD.D)
        x, _ = m.forward_map(z, None, ctx)
        out.append(x.view(-1, n, MD.D))
    return torch.cat(out).numpy()


@torch.no_grad()
def flow_lp(m, X, C):
    return m.log_prob(torch.as_tensor(X), torch.as_tensor(C)).numpy()


def predictive(name, C, n=200):
    if name in models:
        return flow_samples(models[name], C, n)
    if name == "GP surrogate":
        mu, sd = gp.predict(C)
        return mu[:, None, :] + sd[:, None, :] * rng.standard_normal((len(C), n, MD.D))
    return np.stack([MD.bnn_sample(bnn, c, n) for c in C])


def logprob(name, X, C):
    if name in models:
        return flow_lp(models[name], X, C)
    if name == "GP surrogate":
        return gp.logprob(X, C)
    return MD.bnn_logprob(bnn, X, C)


NAMES = list(models) + ["GP surrogate", "MF-BNN"]
res = {"seed": SEED, "lambda": lam, "lambda_nodesc": lam0, "lambda_concat": lamc, "beta": beta_sel, "beta_concat": beta_c, "train_time_s": timing}

# (a) per-build prediction on the 300 test builds x 2 lifecycle stages, before (t=0) and after (t=10) the build
test = S["test"]
for t in (0, 10):
    Xt = np.array([A.xstd(b, u) for b in test for u in (0, 1)], dtype=np.float32)
    for name in NAMES:
        use_desc = name != "No descriptors"
        Ct = np.array([A.c_vec(b, u, t, use_desc) for b in test for u in (0, 1)], dtype=np.float32)
        lp = logprob(name, Xt, Ct)
        smp = predictive(name, Ct)
        r = {"nll_per_dim": float(-np.mean(lp) / MD.D)}
        for pname, j in PROPS.items():
            truth = Xt[:, j]
            mean = smp[:, :, j].mean(1)
            r[f"rmse {pname}"] = float(np.sqrt(np.mean((mean - truth) ** 2)) * A.xs[j])
            ces = []
            for a in LEVELS:
                lo, hi = np.quantile(smp[:, :, j], [(1 - a) / 2, (1 + a) / 2], axis=1)
                cov = np.mean((truth >= lo) & (truth <= hi))
                r[f"coverage {a} {pname}"] = float(cov)
                r[f"width {a} {pname}"] = float(np.mean(hi - lo) * A.xs[j])
                ces.append(abs(cov - a))
            r[f"ECE {pname}"] = float(np.mean(ces))
        res[f"test t={t} {name}"] = r
    print("eval t", t, round(time.time() - t0), flush=True)


# (b) distributional fidelity at the three reference points (pre-build, t = 0)
def n_modes(v, grid):
    kde = gaussian_kde(v, bw_method=0.25 / max(np.std(v), 1e-6))
    y = kde(grid)
    pk, _ = find_peaks(y, prominence=0.08 * y.max())
    return max(len(pk), 1)


def mmd(Xa, Xb):
    from chain import matern32
    Z = np.vstack([Xa, Xb])
    dd = np.sqrt(((Z[:300, None] - Z[None, :300]) ** 2).sum(-1))
    ell = float(np.median(dd[dd > 0]))
    kaa = matern32(Xa, Xa, ell).mean(); kbb = matern32(Xb, Xb, ell).mean(); kab = matern32(Xa, Xb, ell).mean()
    return float(np.sqrt(max(kaa + kbb - 2 * kab, 0)))


for k, R in enumerate(S["ref"]):
    for u in (0, 1):
        Xr = np.array([A.xstd(b, u) for b in R])
        c = A.c_vec(R[0], u, 0)[None].astype(np.float32)
        for name in NAMES:
            smp = predictive(name, np.repeat(c, 1, 0), n=1000)[0]
            w2 = float(np.sqrt(ot.emd2(np.full(1000, 1e-3), np.full(len(Xr), 1 / len(Xr)), ot.dist(smp, Xr))))
            modes = []
            for j in (2, 6):
                grid = np.linspace(min(Xr[:, j].min(), smp[:, j].min()) - 0.5, max(Xr[:, j].max(), smp[:, j].max()) + 0.5, 400)
                modes.append(n_modes(smp[:, j], grid) / n_modes(Xr[:, j], grid))
            res[f"ref R{k + 1} u={u} {name}"] = {"W2": w2, "MMD": mmd(smp[:400], Xr), "mode_ratio": float(np.mean(modes)),
                                               "ref_modes": [n_modes(Xr[:, j], np.linspace(Xr[:, j].min() - .5, Xr[:, j].max() + .5, 400)) for j in (2, 6)]}

# (c) inference latency (one conditional posterior, 1000 samples)
for name in NAMES:
    c = A.c_vec(test[0], 0, 10).astype(np.float32)[None]
    ts_ = []
    for _ in range(20):
        tq = time.perf_counter(); predictive(name, c, n=1000); ts_.append(time.perf_counter() - tq)
    res[f"latency_ms {name}"] = float(np.median(ts_) * 1e3)

json.dump(res, open(f"{OUT}/forward_seed{SEED}.json", "w"), indent=1)
print("done", round(time.time() - t0), flush=True)
